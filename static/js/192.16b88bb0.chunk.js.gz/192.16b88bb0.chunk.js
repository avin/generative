(this.webpackJsonpgenerative=this.webpackJsonpgenerative||[]).push([[192],{316:function(n,e,h){"use strict";h.r(e),e.default=`#define GLSLIFY 1
vec3 hueCol = hue(hash11(vIdx*.005) * sin(vR*5.*hash11(vIdx*.00132)) * .25 + .1).rgb;
vec3 col = COL * (hash11(vIdx*.005)*.75 + .5);
diffuseColor = hueCol;
`}}]);
