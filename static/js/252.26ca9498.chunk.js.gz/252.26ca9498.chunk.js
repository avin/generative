(this.webpackJsonpgenerative=this.webpackJsonpgenerative||[]).push([[252],{426:function(i,e,t){"use strict";t.r(e),e.default=`#define GLSLIFY 1
float updateTime = iTime * .1;

vec3 distortedNormal = distortNormal(position, positionUpdated, normalUpdated);
normalUpdated = distortedNormal;
`}}]);
