(this.webpackJsonpgenerative=this.webpackJsonpgenerative||[]).push([[99,180,181],{301:function(p,e,n){"use strict";n.r(e),e.default=`#define GLSLIFY 1
attribute vec3 position;
attribute vec2 uv;

varying vec2 vUv;
varying vec3 pPos;
varying float rSize;

uniform float iTime;
uniform float aRatio;
uniform float stackSize;
uniform float sizeStep;
uniform float pSize;
uniform vec3 camPos;

uniform mat4 worldViewProjection;
uniform mat4 world;

#define PI 3.1415926;
#define PI2 6.28318530;
#define rand1(p) fract(sin(p * 78.233) * 43758.5453)

//
// Description : Array and textureless GLSL 2D/3D/4D simplex
//               noise functions.
//      Author : Ian McEwan, Ashima Arts.
//  Maintainer : ijm
//     Lastmod : 20110822 (ijm)
//     License : Copyright (C) 2011 Ashima Arts. All rights reserved.
//               Distributed under the MIT License. See LICENSE file.
//               https://github.com/ashima/webgl-noise
//

vec3 mod289(vec3 x) {
  return x - floor(x * (1.0 / 289.0)) * 289.0;
}

vec4 mod289(vec4 x) {
  return x - floor(x * (1.0 / 289.0)) * 289.0;
}

vec4 permute(vec4 x) {
     return mod289(((x*34.0)+1.0)*x);
}

vec4 taylorInvSqrt(vec4 r)
{
  return 1.79284291400159 - 0.85373472095314 * r;
}

float snoise(vec3 v)
  {
  const vec2  C = vec2(1.0/6.0, 1.0/3.0) ;
  const vec4  D = vec4(0.0, 0.5, 1.0, 2.0);

// First corner
  vec3 i  = floor(v + dot(v, C.yyy) );
  vec3 x0 =   v - i + dot(i, C.xxx) ;

// Other corners
  vec3 g = step(x0.yzx, x0.xyz);
  vec3 l = 1.0 - g;
  vec3 i1 = min( g.xyz, l.zxy );
  vec3 i2 = max( g.xyz, l.zxy );

  //   x0 = x0 - 0.0 + 0.0 * C.xxx;
  //   x1 = x0 - i1  + 1.0 * C.xxx;
  //   x2 = x0 - i2  + 2.0 * C.xxx;
  //   x3 = x0 - 1.0 + 3.0 * C.xxx;
  vec3 x1 = x0 - i1 + C.xxx;
  vec3 x2 = x0 - i2 + C.yyy; // 2.0*C.x = 1/3 = C.y
  vec3 x3 = x0 - D.yyy;      // -1.0+3.0*C.x = -0.5 = -D.y

// Permutations
  i = mod289(i);
  vec4 p = permute( permute( permute(
             i.z + vec4(0.0, i1.z, i2.z, 1.0 ))
           + i.y + vec4(0.0, i1.y, i2.y, 1.0 ))
           + i.x + vec4(0.0, i1.x, i2.x, 1.0 ));

// Gradients: 7x7 points over a square, mapped onto an octahedron.
// The ring size 17*17 = 289 is close to a multiple of 49 (49*6 = 294)
  float n_ = 0.142857142857; // 1.0/7.0
  vec3  ns = n_ * D.wyz - D.xzx;

  vec4 j = p - 49.0 * floor(p * ns.z * ns.z);  //  mod(p,7*7)

  vec4 x_ = floor(j * ns.z);
  vec4 y_ = floor(j - 7.0 * x_ );    // mod(j,N)

  vec4 x = x_ *ns.x + ns.yyyy;
  vec4 y = y_ *ns.x + ns.yyyy;
  vec4 h = 1.0 - abs(x) - abs(y);

  vec4 b0 = vec4( x.xy, y.xy );
  vec4 b1 = vec4( x.zw, y.zw );

  //vec4 s0 = vec4(lessThan(b0,0.0))*2.0 - 1.0;
  //vec4 s1 = vec4(lessThan(b1,0.0))*2.0 - 1.0;
  vec4 s0 = floor(b0)*2.0 + 1.0;
  vec4 s1 = floor(b1)*2.0 + 1.0;
  vec4 sh = -step(h, vec4(0.0));

  vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy ;
  vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww ;

  vec3 p0 = vec3(a0.xy,h.x);
  vec3 p1 = vec3(a0.zw,h.y);
  vec3 p2 = vec3(a1.xy,h.z);
  vec3 p3 = vec3(a1.zw,h.w);

//Normalise gradients
  vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2, p2), dot(p3,p3)));
  p0 *= norm.x;
  p1 *= norm.y;
  p2 *= norm.z;
  p3 *= norm.w;

// Mix final noise value
  vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
  m = m * m;
  return 42.0 * dot( m*m, vec4( dot(p0,x0), dot(p1,x1),
                                dot(p2,x2), dot(p3,x3) ) );
  }

void main()
{
    vUv = uv;
    pPos = position;

    gl_PointSize = stackSize * sizeStep - position.y * sizeStep;

    pPos.x += position.y*.01;
    rSize = gl_PointSize;

    float depth = position.y / stackSize;
    float df =  (1. - depth);

    float t = iTime;

    vec3 p  = position * 100.;

    float xf = snoise(vec3(p.x + depth, depth + t, p.z + depth)) *.15 * depth;
    float zf = snoise(vec3(p.x + depth + 100., depth + t, p.z + depth)) *.15  * depth;

    pPos.x += xf - depth*.25;
    pPos.z += zf + depth*.125;

    pPos.z /= aRatio;

    gl_Position = worldViewProjection * vec4(pPos, 1.0);

}
`},302:function(p,e,n){"use strict";n.r(e),e.default=`#define GLSLIFY 1
varying vec3 pPos;
varying float rSize;

varying vec2 vUv;

uniform vec2 iResolution;
uniform float iTime;
uniform float stackSize;

#define BLACK_COL vec3(16,22,26)/255.
#define WHITE_COL vec3(235,241,245)/255.

#define SF 2./min(iResolution.x, iResolution.y)
#define SS(l, s) smoothstep(SF, -SF, l - s)

void mainImage( out vec4 fragColor, in vec2 fragCoord)
{
    vec2 uv = (vec3(gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1)).xy - .5;

    float l = length(uv);

    float sf = 2./rSize;

    float circleLimit = smoothstep(.5, .5 - sf, l);

    float ll = .1;
    float g = smoothstep(sf, -sf, abs(l - (.5 - sf * 1.75)));

    float depthFactor = pPos.y / stackSize;

    vec3 col = mix(BLACK_COL, WHITE_COL, g * depthFactor);

    fragColor = vec4(col, circleLimit);
}

void main()
{
    mainImage(gl_FragColor, vUv * iResolution.xy);
}
`},549:function(p,e,n){"use strict";n.d(e,"a",function(){return h});const f=()=>!!document.createElement("canvas").getContext("webgl2"),h=()=>f()?"webgl2":"webgl"},78:function(p,e,n){"use strict";n.r(e);var f=n(445),h=n(449),E=n(451),d=n(475),z=n(435),S=n(665),M=n(509),w=n(441),D=n(506),L=n(549),R=n(301),O=n(302),b=(y,u,m)=>new Promise((g,c)=>{var i=s=>{try{r(m.next(s))}catch(l){c(l)}},t=s=>{try{r(m.throw(s))}catch(l){c(l)}},r=s=>s.done?g(s.value):Promise.resolve(s.value).then(i,t);r((m=m.apply(y,u)).next())});const A={animate:!0,context:Object(L.a)()},I=y=>b(void 0,[y],function*({canvas:u,width:m,height:g}){const c=new f.a(u,!0,{preserveDrawingBuffer:!0,stencil:!0}),i=new h.a(c);i.clearColor=new w.a(16/255,22/255,26/255),z.a.ShadersStore.particlesVertexShader=R.default,z.a.ShadersStore.particlesFragmentShader=O.default;const t=new D.a("camera1",0,0,1e4,d.z.Zero(),i);t.setTarget(d.z.Zero()),t.mode=E.a.ORTHOGRAPHIC_CAMERA,t.orthoTop=1,t.orthoBottom=-1,t.orthoLeft=-1,t.orthoRight=1;const r=new S.b("pcs",0,i),s=.75,l=150,P=i.getEngine().getAspectRatio(t),T=200*P,C=[];for(let a=0;a<T;a+=1){const v=(Math.random()-.5)*2,x=(Math.random()-.5)*2*P;C.push([v,x])}for(let a=0;a<l;a+=1)C.forEach(([v,x])=>{r.addPoints(1,_=>{_.position=new d.z(v,a,x)})});yield r.buildMeshAsync();const o=new M.a("shader",i,{vertex:"particles",fragment:"particles"},{attributes:["position","normal","uv"],uniforms:["world","worldView","worldViewProjection","view","iTime","iResolution","pSize","stackSize","sizeStep","aRatio"],needAlphaBlending:!0});return o.pointsCloud=!0,o.setFloat("iResolution",new d.y(1,1)),o.setFloat("pSize",1),o.setFloat("stackSize",l),o.setFloat("sizeStep",s),o.setFloat("aRatio",1),r.mesh.material=o,{render({time:a,width:v,height:x}){o.setFloat("iTime",a),o.setFloat("aRatio",v/x);const _=i.getEngine().getAspectRatio(t);o.setVector2("iResolution",new d.y(_,1)),i.render()},resize({pixelRatio:a,width:v,height:x}){c.resize()},unload(){c.dispose()}}});e.default={sketch:I,settings:A}}}]);
