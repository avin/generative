(this.webpackJsonpgenerative=this.webpackJsonpgenerative||[]).push([[207],{327:function(a,n,e){"use strict";e.r(n),n.default=`#define GLSLIFY 1
varying float vR;
varying float vIdx;
varying float vR1Factor;
varying float vR2Factor;

#define COL1 vec3(72, 175, 240) / 255.0
#define COL2 vec3(255, 179, 102) / 255.0
#define COL3 vec3(255, 102, 161) / 255.0
`}}]);
