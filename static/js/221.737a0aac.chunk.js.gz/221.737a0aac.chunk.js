(this.webpackJsonpgenerative=this.webpackJsonpgenerative||[]).push([[221],{342:function(t,i,e){"use strict";e.r(i),i.default=`#define GLSLIFY 1
float t = iTime * speed;
float k = positionUpdated.z * factor;
positionUpdated.x += sin(k - t) * swingSize;
positionUpdated.y += cos(k - t) * swingSize;
`}}]);
