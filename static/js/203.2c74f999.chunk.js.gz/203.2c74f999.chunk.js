(this.webpackJsonpgenerative=this.webpackJsonpgenerative||[]).push([[203],{323:function(t,n,a){"use strict";a.r(n),n.default=`#define GLSLIFY 1
varying float vR;
varying float vIdx;
varying float vR1Factor;
varying float vR2Factor;
`}}]);
