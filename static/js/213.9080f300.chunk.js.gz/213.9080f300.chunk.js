(this.webpackJsonpgenerative=this.webpackJsonpgenerative||[]).push([[213],{333:function(i,e,n){"use strict";n.r(e),e.default=`#extension GL_OES_standard_derivatives : enable
#define GLSLIFY 1

varying float vR;
varying vec2 vUv;

#define COL1 vec3(32, 43, 51) / 255.0
#define COL2 vec3(235, 241, 245) / 255.0
`}}]);
